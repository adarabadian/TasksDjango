from . import views
from django.urls import path, include
from rest_framework.routers import DefaultRouter


#always use this for routing
router = DefaultRouter()
router.register('tasks', views.TaskViewSet)

urlpatterns = [
    path('v1/', include(router.urls))
]